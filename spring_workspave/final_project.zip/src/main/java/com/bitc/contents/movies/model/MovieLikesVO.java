package com.bitc.contents.movies.model;

import lombok.Data;

@Data
public class MovieLikesVO {

	private int likes_id;
	private int mv_num;
	private int num;

}
