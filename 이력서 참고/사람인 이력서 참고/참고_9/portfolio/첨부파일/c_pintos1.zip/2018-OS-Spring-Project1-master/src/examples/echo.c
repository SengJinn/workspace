#include <stdio.h>
#include <syscall.h>

int
main (int argc, char **argv)
{
    printf ("hello world\n");

}
