#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include <stdbool.h>
#include <debug.h>
#include "threads/vaddr.h"	// for is_user_vaddr (*vaddr)
#include "userprog/pagedir.h"	// for pagedir_get_page
#include "lib/kernel/list.h"
#include "threads/synch.h"
#include "threads/palloc.h"
static struct lock locking;

static int fd_seed;

static struct file_node
{
  int fd;
  struct file* file_ptr;
  struct list_elem elem;
};

static struct list file_list;

static void sys_halt (void) NO_RETURN;
static void sys_exit (int status) NO_RETURN;
//pid_t exec (const char *file);
//int wait (pid_t);
static bool sys_create (const char *file, unsigned initial_size);
//bool remove (const char *file);
static int sys_open (const char *file);
//int filesize (int fd);
//int read (int fd, void *buffer, unsigned length);
static int sys_write (int fd, const void *buffer, unsigned length);
//void seek (int fd, unsigned position);
//unsigned tell (int fd);
static void sys_close (int fd);

static void syscall_handler (struct intr_frame *);

void
syscall_init (void)
{
  //printf("init\n");
  lock_init(&locking);
  list_init(&file_list);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}


static void
sys_halt (void)
{
  //printf("halt\n");
  shutdown_power_off();
}

/* Terminates the current user program, returning status to the
   kernel. If the process’s parent waits for it (see below),
   this is the status that will be returned. Conventionally,
   a status of 0 indicates success and nonzero values indicate
   errors. */
static void
sys_exit (int status)
{

  //printf("exit, %d\n", status);
  printf("%s: exit(%i)\n",thread_current()->name, status);
  thread_exit();
}

/* Creates a new file called FILE initially INITIAL_SIZE bytes
   in size. Returns true if successful, false otherwise. Creating
   a new file does not open it: opening the new file is a separate
   operation which would require a open system call. */
static bool
sys_create (const char *file, unsigned initial_size)
{
  bool creation = 0;
  void *paging = pagedir_get_page(thread_current() -> pagedir, file);
  if (!paging)
    {sys_exit(-1);}
  //printf("create, %s, %d\n", file, initial_size);	// *char?? char??
  else if (file == NULL || *file == NULL)
    {sys_exit(-1);}
  else
  {
    lock_acquire(&locking);
    creation = filesys_create(file, initial_size);
  //printf("the creation status: %i\n",creation);
    lock_release(&locking);
  }
  return creation;
  //return filesys_create(file, initial_size);
}

/* Opens the file called FILE. Returns a nonnegative integer handle
   called a “file descriptor” (fd), or -1 if the file could not be
   opened.

   File descriptors numbered 0 and 1 are reserved for the console:
   fd 0 (STDIN_FILENO) is standard input, fd 1 (STDOUT_FILENO) is
   standard output. The open system call will never return either of
   these file descriptors, which are valid as system call arguments
   only as explicitly described below.

   Each process has an independent set of file descriptors. File
   descriptors are not inherited by child processes.

   When a single file is opened more than once, whether by a single
   process or different processes, each open returns a new file
   descriptor. Different file descriptors for a single file are
   closed independently in separate calls to close and they do not
   share a file position. */
static int
sys_open (const char *file)
{
  static struct file_node* file_to_open;

  void *paging = pagedir_get_page(thread_current() -> pagedir, file);
  if (!paging)
    sys_exit(-1);

  lock_acquire(&locking);
  //int fd;
  //struct file* file_ptr;
  //printf("open, %s\n", file);
  if(file == NULL)
    {
      //sys_exit(-1);
      lock_release(&locking);
      return -1;
    }
  if(*file == NULL)
  {
    lock_release(&locking);
    printf("(open-empty) end\n");
    sys_exit(0);
    return -1;
  }

  file_to_open = palloc_get_page(PAL_USER);
  file_to_open->file_ptr = filesys_open(file);
  if(!file_to_open->file_ptr)
  {
    palloc_free_page(file_to_open);
    lock_release(&locking);
    printf("(open-missing) end\n");
    sys_exit(0);
    return -1;
  }
  else{
    if(list_empty(&file_list))
      fd_seed = 3;

    file_to_open->fd = fd_seed++;

    list_push_front(&file_list, &file_to_open->elem);
  //after here allocate an fd value to file_ptr
  //if the file not opne fd = -1
    lock_release(&locking);
    return file_to_open->fd;
  }
}

/* Writes size bytes from buffer to the open file fd. Returns
   the number of bytes actually written, which may be less than
   size if some bytes could not be written.

   Writing past end-of-file would normally extend the file, but
   file growth is not implemented by the basic file system. The
   expected behavior is to write as many bytes as possible up to
   end-of-file and return the actual number written, or 0 if no
   bytes could be written at all.

   Fd 1 writes to the console. Your code to write to the console
   should write all of buffer in one call to putbuf(), at least
   as long as size is not bigger than a few hundred bytes.
   (It is reasonable to break up larger buffers.) Otherwise,
   lines of text output by different processes may end up
   interleaved on the console, confusing both human readers and
   our grading scripts. */
static int
sys_write (int fd, const void *buffer, unsigned size)
{
  int written_size =0;
  struct file_node* file_to_write;
  //struct file* file_ptr;
  struct list_elem *e;

  void *paging = pagedir_get_page(thread_current() -> pagedir, buffer);
  if (!paging)
    sys_exit(-1);

  lock_acquire(&locking);
  //printf("write, %d, %d\n", fd, size);
  if (fd == STDOUT_FILENO){
    putbuf(buffer,size);
    lock_release(&locking);
    return size;
  }
  else {
    for(e = list_begin(&file_list); e != list_end(&file_list); e = list_next(e))
      {
        file_to_write = list_entry(e, struct file_node, elem);
        if (file_to_write->fd == fd)
        break;
      }
    if(e == list_end(&file_list))
        sys_exit(-1);
    written_size = file_write(file_to_write->file_ptr,buffer,size);//before here, find file_ptr from fd value
    lock_release(&locking);
    return written_size;
  }

}

/* Closes file descriptor fd. Exiting or terminating a process
   implicitly closes all its open file descriptors, as if by
   calling this function for each one. */
static void
sys_close (int fd)
{
  struct file_node* file_to_close;
  struct list_elem *e;
  lock_acquire(&locking);
  if (fd >2){
    for (e = list_begin(&file_list); e != list_end(&file_list); e = list_next(e))
    {
      file_to_close = list_entry(e, struct file_node, elem);
      if (file_to_close->fd == fd)
        break;
    }
    if (e == list_end(&file_list))
      {sys_exit(-1);}
    else {
      list_remove(e);
      file_close(file_to_close->file_ptr);
      palloc_free_page(file_to_close);//struct file_node as an argument
      }
  }//printf("close, %d\n", fd);
  lock_release(&locking);
}

static void	// static inline bool is_user_vaddr (const void *vaddr)
syscall_handler (struct intr_frame *f UNUSED)
{ // halt, exit, create, open, write, close
int *sp = f -> esp;
void *paging = pagedir_get_page(thread_current() -> pagedir, sp);

if (paging) {}
else {sys_exit(-1);}
if (is_user_vaddr (sp) && sp != NULL) {}
else {sys_exit(-1);}
//printf("syscall_handler with num %d\n", *(int *) sp);
switch (*sp) {
  case SYS_HALT:	// sys_halt (void), power off computer

    sys_halt();
    break;

  case SYS_EXIT:	// sys_exit (int status), turn off user process

  if (is_user_vaddr ((sp+1)) && (sp+1) != NULL) {}
  else {sys_exit(-1);}

    sys_exit(*(sp+1));
    break;

  case SYS_CREATE:	// sys_create (const char *file, unsigned initial_size)

  if (is_user_vaddr ((sp+4)) && (sp+4) != NULL) {}
  else {sys_exit(-1);}
  if (is_user_vaddr ((sp+5)) && (sp+5) != NULL) {}
  else {sys_exit(-1);}

    f->eax = sys_create((char *) *(sp+4), *(sp+5));
    break;

  case SYS_OPEN:	// sys_open (const char *file)

  if (is_user_vaddr ((sp+1)) && (sp+1) != NULL) {}
  else {sys_exit(-1);}

    f->eax = sys_open((char *) *(sp+1));
    break;

  case SYS_WRITE:	// sys_write (int fd, const void *buffer, unsigned size)

  if (is_user_vaddr ((sp+5)) && (sp+5) != NULL) {}
  else {sys_exit(-1);}
  if (is_user_vaddr ((sp+6)) && (sp+6) != NULL) {}
  else {sys_exit(-1);}
  if (is_user_vaddr ((sp+7)) && (sp+7) != NULL) {}
  else {sys_exit(-1);}

    f->eax = sys_write(*(sp+5), (void *) *(sp+6), *(sp+7));
    break;

  case SYS_CLOSE:	// sys_close (int fd)

  if (is_user_vaddr ((sp+1)) && (sp+1) != NULL) {}
  else {sys_exit(-1);}

    sys_close(*(sp+1));
    break;

  defalult:
    sys_exit(-1);
}
/*  void *sp, **temp;	// uintptr_r is another option
  int argc;
  uintptr_t argv;	// maybe malloc is needed
  char *fn;
  char *char_arg;
  int int_arg;
  unsigned unsigned_arg;
  void *void_arg;

  char *Halt = "halt", *Exit = "exit", *Create = "create", *Open = "open", *Write = "write", *Close = "close";

  sp = f -> esp;
pritnf ("esp is %d\n", *sp);
  sp += sizeof (void *); // now argc
  memcpy (&argc, sp, sizeof (int));
  sp += sizeof (void *); // now argv
  argv = sp;
  sp += sizeof (void *); // now argv[0]
//  strlcpy (fn, *argv, strlen (*argv) + 1); // I'm not sure

  if (1) {
    if (strcmp (Halt, fn) == 0) { // 0
      sys_halt ();
    }

    else if (strcmp (Exit, fn) == 0) { // 1
      sp += 4;
      memcpy (temp, sp, sizeof (int *));	// If it doesn't work,
      memcpy (&int_arg, *temp, sizeof (int));	// use argument, not address

      sys_exit (int_arg);
    }

    else if (strcmp (Create, fn) == 0) { // 2
      sp += 4;
      memcpy (temp, sp, sizeof (char **));
      strlcpy (char_arg, *temp, sizeof (char *) + 1);

      sp += 4;
      memcpy (temp, sp, sizeof (unsigned *));
      memcpy (&unsigned_arg, *temp, sizeof (unsigned));

      sys_create (char_arg, unsigned_arg);
    }

    else if (strcmp (Open, fn) == 0) { // 1
      sp += 4;
      memcpy (temp, sp, sizeof (char **));
      strlcpy (char_arg, *temp, sizeof (char *) + 1);

      sys_open (char_arg);
    }

    else if (strcmp (Write, fn) == 0) { // 3
      sp += 4;
      memcpy (temp, sp, sizeof (int *));	// If it doesn't work,
      memcpy (&int_arg, *temp, sizeof (int));	// use argument, not address

      sp += 4;
      memcpy (temp, sp, sizeof (void **));
      memcpy (void_arg, *temp, sizeof (void *));

      sp += 4;
      memcpy (temp, sp, sizeof (unsigned *));
      memcpy (&unsigned_arg, *temp, sizeof (unsigned));

      sys_write (int_arg, void_arg, unsigned_arg);
    }

    else if (strcmp (Close, fn) == 0) { // 1
      sp += 4;
      memcpy (temp, sp, sizeof (int *));
      memcpy (&int_arg, *temp, sizeof (int));

      sys_close (int_arg);
    }
  }*/
//  printf ("system call!\n");

}
