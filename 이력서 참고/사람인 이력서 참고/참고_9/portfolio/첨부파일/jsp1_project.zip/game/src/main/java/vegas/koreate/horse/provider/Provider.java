package vegas.koreate.horse.provider;

public class Provider {

}
