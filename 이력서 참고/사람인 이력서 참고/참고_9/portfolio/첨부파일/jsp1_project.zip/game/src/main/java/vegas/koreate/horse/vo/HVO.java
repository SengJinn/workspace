package vegas.koreate.horse.vo;

import lombok.Data;

@Data
public class HVO {
private int hnum;
private int hbet;
private int gambler_num;


}
