package vegas.koreate.horse.vo;

import lombok.Data;

@Data
public class WHVO {

	
	private int winner;
	private double price;
	private int hbet;
	private int gambler_num;
	private int vitory_num;
	private int totalbet;
	private int victory_man_bet;
	private int victory_horse_bet;
}
